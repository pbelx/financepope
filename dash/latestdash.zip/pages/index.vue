<template>
    <v-container>
        <h1>Finance Index</h1>
    </v-container>
</template>